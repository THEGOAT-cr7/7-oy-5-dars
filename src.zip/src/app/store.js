import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./feature/userSlice";

const store = configureStore({
  reducer: {
    user: userReducer,
  },
});

export default store;
